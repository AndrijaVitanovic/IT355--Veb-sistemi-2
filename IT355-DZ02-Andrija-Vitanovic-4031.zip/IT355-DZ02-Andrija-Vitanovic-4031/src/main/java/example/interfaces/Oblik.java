package example.interfaces;

public interface Oblik {
    double obim();
    double povrsina();
}
