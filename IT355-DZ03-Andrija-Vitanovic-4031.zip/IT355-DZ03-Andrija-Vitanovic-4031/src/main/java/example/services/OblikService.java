package example.services;

import example.interfaces.Oblik;
import org.springframework.stereotype.Service;


@Service

public class OblikService {
    public double izracunajObim(Oblik oblik) {
        return oblik.obim();
    }

    public double izracunajPovrsinu(Oblik oblik) {
        return oblik.povrsina();
    }
}
