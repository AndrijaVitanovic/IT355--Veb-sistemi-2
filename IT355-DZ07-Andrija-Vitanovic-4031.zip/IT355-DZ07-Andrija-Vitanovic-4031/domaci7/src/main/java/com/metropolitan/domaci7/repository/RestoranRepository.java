package com.metropolitan.domaci7.repository;

import com.metropolitan.domaci7.model.Restoran;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RestoranRepository extends JpaRepository<Restoran, Long> {
}
