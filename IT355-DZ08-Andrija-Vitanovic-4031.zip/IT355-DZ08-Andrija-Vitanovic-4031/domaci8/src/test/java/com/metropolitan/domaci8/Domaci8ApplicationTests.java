package com.metropolitan.domaci8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Domaci8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
