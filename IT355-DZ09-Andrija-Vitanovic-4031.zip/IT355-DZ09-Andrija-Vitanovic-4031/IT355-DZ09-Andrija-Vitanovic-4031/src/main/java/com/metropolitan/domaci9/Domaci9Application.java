package com.metropolitan.domaci9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Domaci9Application {

	public static void main(String[] args) {
		SpringApplication.run(Domaci9Application.class, args);
	}

}
