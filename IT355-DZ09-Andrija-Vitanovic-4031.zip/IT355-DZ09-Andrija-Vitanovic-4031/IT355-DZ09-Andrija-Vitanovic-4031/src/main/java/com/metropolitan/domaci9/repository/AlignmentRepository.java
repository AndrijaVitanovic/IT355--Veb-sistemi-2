package com.metropolitan.domaci9.repository;

import com.metropolitan.domaci9.model.Alignment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlignmentRepository extends JpaRepository<Alignment, Integer> {
}
