package com.metropolitan.domaci9.repository;

import com.metropolitan.domaci9.model.Colour;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ColourRepository extends JpaRepository<Colour, Integer> {
}
