package com.metropolitan.domaci9.repository;

import com.metropolitan.domaci9.model.HeroAttribute;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HeroAttributeRepository extends JpaRepository<HeroAttribute, Integer> {
}
