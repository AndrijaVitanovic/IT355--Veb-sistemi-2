package com.metropolitan.domaci9.repository;

import com.metropolitan.domaci9.model.Superpower;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SuperpowerRepository extends JpaRepository<Superpower, Integer> {
}
