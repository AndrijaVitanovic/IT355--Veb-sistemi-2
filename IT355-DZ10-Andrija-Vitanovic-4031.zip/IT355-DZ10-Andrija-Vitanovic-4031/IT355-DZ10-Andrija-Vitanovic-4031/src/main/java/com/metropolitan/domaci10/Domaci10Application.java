package com.metropolitan.domaci10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Domaci10Application {

	public static void main(String[] args) {
		SpringApplication.run(Domaci10Application.class, args);
	}

}
