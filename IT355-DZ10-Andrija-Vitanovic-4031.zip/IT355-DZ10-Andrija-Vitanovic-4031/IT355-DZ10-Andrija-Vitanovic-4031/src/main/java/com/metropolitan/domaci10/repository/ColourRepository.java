package com.metropolitan.domaci10.repository;

import com.metropolitan.domaci10.model.Colour;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ColourRepository extends JpaRepository<Colour, Integer> {
}
