package com.metropolitan.domaci10.repository;

import com.metropolitan.domaci10.model.HeroAttribute;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HeroAttributeRepository extends JpaRepository<HeroAttribute, Integer> {
}
