package com.metropolitan.domaci10.repository;

import com.metropolitan.domaci10.model.Superpower;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SuperpowerRepository extends JpaRepository<Superpower, Integer> {
}
