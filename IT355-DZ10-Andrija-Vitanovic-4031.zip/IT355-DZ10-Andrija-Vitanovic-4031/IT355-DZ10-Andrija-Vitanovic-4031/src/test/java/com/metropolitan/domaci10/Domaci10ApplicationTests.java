package com.metropolitan.domaci10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Domaci10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
