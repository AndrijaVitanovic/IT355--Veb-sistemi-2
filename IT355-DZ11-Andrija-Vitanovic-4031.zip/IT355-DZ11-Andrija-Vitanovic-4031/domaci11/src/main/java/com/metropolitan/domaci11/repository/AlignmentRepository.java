package com.metropolitan.domaci10.repository;

import com.metropolitan.domaci10.model.Alignment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlignmentRepository extends JpaRepository<Alignment, Integer> {
}
